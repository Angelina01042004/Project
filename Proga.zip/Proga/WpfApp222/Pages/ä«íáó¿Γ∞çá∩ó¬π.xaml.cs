﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp222.Entities;

namespace WpfApp222.Pages
{
    /// <summary>
    /// Логика взаимодействия для ДобавитьЗаявку.xaml
    /// </summary>
    /// 
    public partial class ДобавитьЗаявку : Page
    {
    

        private Order _currentOrder = new Order();
        private int _equipment = 0;
        private int _defect = 0;
        public ДобавитьЗаявку()
        {
            InitializeComponent();

            DataContext = _currentOrder;

           Equipment_cb.ItemsSource= App.Context.Equipment.ToList();
            Defect_cb.ItemsSource=App.Context.Defect.ToList();  
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Frame());
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
          
         
            try
            {
                var order = new Order
                { 
                    Add_date = DateTime.Now,
                    Problem = Problem_tb.Text,
                    ID_status=1,
                    ID_equipment=_equipment,
                    ID_defect=_defect,
                    ID_client= App.CurrentUser.ID_USER,
                
            };
                App.GetContext.Order.Add(order);
                App.GetContext.SaveChanges();
                MessageBox.Show("Order saved", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                this.NavigationService.Navigate(new Frame());

            }
            catch 
            {
                MessageBox.Show("Error", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }



        }

        private void Equipment_cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Equipment equipmentCB = Equipment_cb.SelectedItem as Equipment;
            _equipment = equipmentCB.ID_EQUIPMENT;

        }

        private void Defect_cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Defect defCB = Defect_cb.SelectedItem as Defect;
            _defect = defCB.ID_DEFECT;
        }
    }
}
