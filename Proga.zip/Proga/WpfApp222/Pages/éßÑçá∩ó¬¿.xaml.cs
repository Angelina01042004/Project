﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp222.Entities;

namespace WpfApp222.Pages
{
    /// <summary>
    /// Логика взаимодействия для ВсеЗаявки.xaml
    /// </summary>
    public partial class ВсеЗаявки : Page
    {
        Order _currentOrder = new Order();

        public ВсеЗаявки()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Frame());
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if(Visibility == Visibility.Visible) 
            {
                //App.GetContext.ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
              //  GridOrders.ItemsSource= App.GetContext.Order.ToList();
              
            }
        }

        private void www_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (www.SelectedIndex == 0 )
            {
                GridOrders.ItemsSource = App.GetContext.Order.Where(x => x.ID_status == 1).ToList();
            }
            if (www.SelectedIndex == 1)
            {
                GridOrders.ItemsSource = App.GetContext.Order.Where(x => x.ID_status == 2).ToList();
            }
            if (www.SelectedIndex == 2)
            {
                GridOrders.ItemsSource = App.GetContext.Order.Where(x => x.ID_status == 3).ToList();
            }
            if (www.SelectedIndex == 3)
            {
                GridOrders.ItemsSource = App.GetContext.Order.Where(x => x.ID_status == 4).ToList();
            }
            if (www.SelectedIndex == 4)
            {
                GridOrders.ItemsSource = App.GetContext.Order.Where(x => x.ID_status == 5).ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
                var removeTask = GridOrders.SelectedItems.Cast<Order>().ToList();

                if (MessageBox.Show($"Выбрана {removeTask.Count()} строка, удалить ", "Attention!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        App.GetContext.Order.RemoveRange(removeTask);
                        App.GetContext.SaveChanges();
                        MessageBox.Show("Готово");

                        GridOrders.ItemsSource = App.GetContext.Order.ToList();
                    }
                    catch
                    {

                        MessageBox.Show("Попробуйте ещё раз", "Системная ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            
        }
    }
}
